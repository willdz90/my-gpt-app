// src/pages/Login.jsx
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../utils/axiosInstance';
import { toast } from 'react-toastify';

export default function Login() {
  const [form, setForm] = useState({ email: '', password: '' });
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const res = await api.post('/api/auth/login', form);
      const token = res.data.token;

      localStorage.setItem('token', token);
      localStorage.setItem('token_expiration', Date.now() + 60 * 60 * 1000); // 1 hora
      localStorage.setItem('last_activity', Date.now());

      toast.success('Sesión iniciada correctamente');
      navigate('/dashboard');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Error al iniciar sesión');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 dark:bg-gray-900">
      <form
        onSubmit={handleSubmit}
        className="bg-white dark:bg-gray-800 p-8 rounded shadow-md space-y-6 w-full max-w-md"
      >
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Iniciar Sesión</h1>

        <input
          type="email"
          name="email"
          placeholder="Correo electrónico"
          value={form.email}
          onChange={handleChange}
          required
          className="w-full p-3 border rounded dark:bg-gray-700 dark:text-white"
        />
        <input
          type="password"
          name="password"
          placeholder="Contraseña"
          value={form.password}
          onChange={handleChange}
          required
          className="w-full p-3 border rounded dark:bg-gray-700 dark:text-white"
        />

        <button
          type="submit"
          disabled={loading}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 rounded"
        >
          {loading ? 'Accediendo...' : 'Iniciar sesión'}
        </button>

        <p className="text-sm text-gray-600 dark:text-gray-400 text-center">
          ¿No tienes cuenta? <a href="/register" className="text-blue-600 dark:text-blue-400 hover:underline">Regístrate</a>
        </p>
      </form>
    </div>
  );
}
