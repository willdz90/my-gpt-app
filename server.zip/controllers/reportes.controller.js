const reportesService = require("../services/reportes.service");
const logger = require("../utils/logger");

exports.ejecutarConsultaPersonalizada = async (req, res) => {
  try {
    const configuracion = req.body;
    const userId = req.user.id;

    const resultado = await reportesService.ejecutar(configuracion, userId);
    res.status(200).json({ ok: true, data: resultado });
  } catch (error) {
    logger.error("Error ejecutando consulta personalizada:", error);
    res.status(500).json({ ok: false, error: "Error ejecutando el reporte." });
  }
};
